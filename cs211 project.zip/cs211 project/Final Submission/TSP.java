package cs211;

import java.util.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.*;




/* Name: Justas Grimaila
 * Student Num: 19340073
 * Email: justas.grimaila.2020@mumail.ie
 * CS211 end of year project: Travelling Salesman
 * 
 * References: General Java Swing Help : https://www.javatpoint.com/java-swing
 * 			   Distance of two points: https://en.wikipedia.org/wiki/Great-circle_distance
 * 			   JPanel and Picture: https://www.dummies.com/programming/java/how-to-write-java-code-to-show-an-image-on-the-screen/
 * 			   Lines: https://www.codejava.net/java-se/graphics/drawing-lines-examples-with-graphics2d
 * 			   
 */


public class TSP extends JFrame {
	//Array List for storing strings of addresses.
	public static ArrayList<String> addresses = new ArrayList<String>();
	//Array List for storing coordinates
	public static ArrayList<Coordinate> coordinates = new ArrayList<Coordinate>();
	//global value of priority of orders.
	public static ArrayList<Integer> orders = new ArrayList<Integer>();
	//variable values for the a,c points of the map
	final static double aLon = -6.71261, aLat = 53.41318, cLon = -6.45509, cLat = 53.28426;

	public static void main(String args[])
	{
		//----GUI STUFF AND BACKGROUND-----
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(EXIT_ON_CLOSE);
		f.getContentPane().setBackground(new Color(200,250,200, 0));
		f.setResizable(false);
		//add the beginning
		Splitter("0,Apache Pizza ,0,53.38197,-6.59274");
		

		//creating GUI Elements for UI 
		
		//Show Points Button
		JButton showButton = new JButton("2. Show");
		showButton.setBounds(675,470,150,60);
		showButton.setBackground(new Color(90,255,90));
		
		//Submit Button
		JButton submitButton = new JButton("1. Submit");
		submitButton.setBounds(675,540,150,60);
		submitButton.setBackground(new Color(255,90,90));
		
		
		//Address Submittion Area
		JTextArea addressarea = new JTextArea("");
		addressarea.setBounds(10,510,650,140);
		addressarea.setBorder(new TitledBorder(null, "Enter Adresses Here -SUBMIT FIRST, THEN PRESS SHOW-", TitledBorder.LEADING, TitledBorder.TOP,null,null));
		addressarea.setLineWrap(true);
		addressarea.setEditable(true);
		addressarea.setVisible(true);
		addressarea.setWrapStyleWord(true);
		
		
		//Order Number List
		JTextArea orderNumList = new JTextArea("");
		orderNumList.setBounds(10,460, 650, 40);
		orderNumList.setBorder(new TitledBorder(null, "Order Number Queue", TitledBorder.LEFT, TitledBorder.TOP, null));
		orderNumList.setEditable(false);
		
		//Map Icon
		ImageIcon mapIcon = new ImageIcon("C:/Users/Justi/Desktop/cs211 project/map.png");
		Image map = mapIcon.getImage();
		Image newmap = map.getScaledInstance(539, 435, java.awt.Image.SCALE_SMOOTH);
		mapIcon = new ImageIcon(newmap);
		//applying the map picture to a JLabel
		
		//Circles
		/*This draws the circles onto the map according to location,
		 * following the usage of the formula of (a->x point) - size of a -> b  
		 * I then multiply it by the width/height of the label
		 * and draw an oval in that place
		 */
		
		JLabel label = new JLabel(mapIcon) {
			@Override
			  protected void paintComponent(Graphics g) {

			    super.paintComponent(g);
			    Graphics2D g2d = (Graphics2D) g;
			    
			    for(Coordinate b: coordinates)
			    {
			    	//drawing the circles
			    	
			    	/* This uses some trigonometric maths. So imagine you have a full length of a-b right? lets call
			    	 * it ab. then you have a x value for this new coordinate, (along with a y). I use the procent
			    	 * of x over ab (and the same idea for the y length) to place the x-value of the coordinate from the arraylist
			    	 * to the jpanel. Took a big chunk of trial and error, but it works wonderfully for mapping.
			    	 */
			    
			    	int x = (int)(((b.getLon() - aLon)/(cLon - aLon)) * this.getWidth());
//			    	System.out.println("x values : " +  x);
			    	int y = (int)(((b.getLat() - aLat)/(cLat - aLat)) * this.getHeight());
//			    	System.out.println("Y values : " +  y);
			    	
			    	g2d.setColor(Color.BLACK);
			    	g2d.fillOval(x-5, y-5, 10, 10);
			    	g2d.setColor(Color.RED);
					g2d.fillOval(x-3, y-3, 6, 6);
					
			    }
			    int i = 0;
			    while((i < (orders.size() - 1)))
			    {
			    	//drawing the lines
			    	//first point
			    	int x1 = (int) (((coordinates.get(orders.get(i)).getLon() - aLon)/(cLon-aLon)) *this.getWidth());
			    	int y1 = (int) (((coordinates.get(orders.get(i)).getLat() - aLat)/(cLat - aLat))*this.getHeight());
			    	
//			    	System.out.println("POINT 1 X: " + x1 + " POINT Y : " + y1);
			    	//second point
			    	int x2 = (int) (((coordinates.get(orders.get(i+1)).getLon() - aLon)/(cLon-aLon)) *this.getWidth());
			    	int y2 = (int) (((coordinates.get(orders.get(i+1)).getLat() - aLat)/(cLat - aLat))*this.getHeight());
			    	
//			    	System.out.println("POINT 2 X: " + x2 + " POINT Y : " + y2);
			    	//draw the lines between these two points
			    	g2d.setPaint(Color.BLACK);
		    		g2d.setStroke(new BasicStroke(1));
					g2d.drawLine(x1, y1, x2, y2);
			    	i++;
			    	System.out.println("");
			    }
			    
	    
			    
			}
		};
		
		//1,38 Parsons Hall Maynooth ,4,53.37521,-6.6103
	
		label.setBounds(125,10,539,435);
		Border border = BorderFactory.createLineBorder(Color.BLACK,3);
		label.setBorder(border);
		
		
		
		//JScrollPane scroll = new JScrollPane (addressarea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		//cant get the scroll to work on the text area. Oh well.
//		JScrollPane scroll = new JScrollPane();
//		scroll.setBounds(250,200,50,200);
//		addressarea.add(scroll);
		
		
		//add the GUI Elements to canvas
		
		f.add(showButton);
		f.add(submitButton);
		f.add(addressarea);
		f.add(orderNumList);
		f.add(label);
		
		
		submitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String areaText = addressarea.getText();
				
				//printing address input stuff
				System.out.println(areaText);
				System.out.println("==============");
				
				String splittedAdresses[] = areaText.split("\\r?\\n");
				for(int i = 0; i < splittedAdresses.length;i++)
				{
					System.out.println(splittedAdresses[i] + "\n");
					Splitter(splittedAdresses[i]);
					orders.add(i+1);
				}
				//testing to see coordinate data
				for(int i = 0; i < coordinates.size();i++)
				{
					System.out.println("Order Num : " + coordinates.get(i).getOrdernum());
					System.out.println("Lat : " + coordinates.get(i).getLat());
					System.out.println("Lon: " + coordinates.get(i).getLon());
					System.out.println("Waittime : " + coordinates.get(i).waittime());
					System.out.println("");
				}
				
				//prioritized number of queues
				//repaint label
				label.repaint();
				
				

			}
		});
		
		
		showButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(orders.size() == 0)
				{
					orderNumList.setText("Nothing submitted!");
				}
				else {
					orderNumList.setText("");
					//sort the queue by amount of time waited, then do nearest neighbour by picking the shortest one
					//of the next two neighbours
					ArrayList<Integer>Temporders = new ArrayList<Integer>();
					Collections.sort(coordinates);
//					//test positions of queue
					for(int i = 0; i < coordinates.size();i++)
					{
						System.out.println("===============");
						System.out.println("Sorted By waittime");
						System.out.println("Sorted Order Num : " + coordinates.get(i).getOrdernum());
						System.out.println("Lat : " + coordinates.get(i).getLat());
						System.out.println("Lon: " + coordinates.get(i).getLon());
						System.out.println("Waittime : " + coordinates.get(i).waittime());
						System.out.println("");
						Temporders.add(coordinates.get(i).ordernum);
					}
					//replace the old arraylist with the new one, where its sorted by waittime
					orders.clear();
					orders.addAll(Temporders);
					Temporders.clear();
					
					//now, sort the array according by comparing an distance of two and then sorting by nearest 2 neighbours
					//out of the priorityqueue that was sorted by waittime
					
					int nearestorder = 0;
					int i =0;
					while(i < orders.size() - 2)
					{
						double lat1 = coordinates.get(i).getLat();
						double lon1 = coordinates.get(i).getLon();
						double lat2 = coordinates.get(i+1).getLat();
						double lon2 = coordinates.get(i+1).getLon();
						
						int dist1 = distance(lon1,lat1, lon2 ,lat2);
						
						double lat3 = coordinates.get(i+2).getLat();
						double lon3 = coordinates.get(i+2).getLon();
						
						int dist2 = distance(lon1,lat1, lon3 ,lat3);
						
						if(dist2 < dist1)
						{
							Collections.swap(orders, i+1, i+2);
						}
						i++;
					}
					//try to also do this,
					// |
					// |
					// V
					
					//I wanted to do a Nearest Neighbour algorithm, but something went wrong with
					//the way I was saving the actual already tested points. Probably an easy fix, but I am
					//blind to it right now.
					for(int x = 0; x < orders.size() - 1;x++)
					{
						double lat1 = coordinates.get(x).getLat();
						double lon1 = coordinates.get(x).getLon();
						for(int j = 1; j < orders.size(); j++)
						{
							int smallestdist = 1000;
							
							double lat2 = coordinates.get(j).getLat();
							double lon2 = coordinates.get(j).getLon();
							//distance between order(i) and order(i+1);
							int dist1 = distance(lon1,lat1, lon2 ,lat2);
							//distance between order(i) and order (i+2)
							if(smallestdist > dist1 && lat1 != lat2 && lon1 != lon2 && Temporders.contains(coordinates.get(j).getOrdernum()) != true)
							{
								//looks for a distance smaller than a made up,
								smallestdist = dist1;
								nearestorder = coordinates.get(j).getOrdernum();
								Temporders.add(nearestorder);
							}
						}
						//adds the one with the smallest distance
						Collections.swap(orders, x + 1, nearestorder);
					}
					
					//bring order 0 to the start
					Collections.swap(orders, orders.indexOf(0), 0);
					System.out.println(orders.toString());
					orderNumList.setText(orders.toString());
					
					label.repaint();
				}
				
			
			}
			
		});
		
		
		
		f.setSize(850,700);
		
		f.setLayout(null);
		
		f.setVisible(true);


	}

	
	
	//splits apart the given input of address, order number, minutes waited, coordinates.
	public static void Splitter(String input)
	{
		int ordernumber = 0;
		
		int minutes = 0;
		
		double latitude = 0;
		
		double longitude = 0;
		
		
		String splittedinput[] = input.split(",", 5);
		
//		for (String s: splittedinput)
//		{
//			System.out.println(s);
//		}
		
		//splitting the different address parts
		ordernumber = Integer.parseInt(splittedinput[0]);
		minutes = Integer.parseInt(splittedinput[2]);
		latitude = Double.parseDouble(splittedinput[3]);
		longitude = Double.parseDouble(splittedinput[4]);
		//stores all the values in a object
		Coordinate co = new Coordinate(ordernumber);
		
		co.setlat(latitude);
		co.setlon(longitude);
		co.setwaittime(minutes);
		//adds the object into an ArrayList of coordinate objects
		coordinates.add(co);
		
		
	}
	
	
	
	public static int distance(double lon1, double lat1, double lon2, double lat2)
	{
		
		double longitude1 = Math.toRadians(lon1);
		double latitude1 = Math.toRadians(lat1);
		double longitude2 = Math.toRadians(lon2);
		double latitude2 = Math.toRadians(lat2);
		//great circle equation for the distance between two points
		double centralangle = Math.acos((Math.sin(latitude1)*Math.sin(latitude2) + Math.cos(latitude1) * Math.cos(latitude2) * Math.cos(longitude1 - longitude2)));
		
		int distance = ((int) (6371 * centralangle));
		
		return distance;
	}

}

class Coordinate implements Comparable<Coordinate>{
	
	public double latitude;
	public double longitude;
	public int ordernum;
	public int waittime;
	
	public Coordinate(int ordernum) {
		this.ordernum = ordernum;
	}
	//setters
	public void setlat(double latitude) {
		this.latitude = latitude;
	}
	
	public void setlon(double longitude)
	{
		this.longitude = longitude;
	}
	
//	public void setordernum(int ordernum) {
//		this.ordernum = ordernum;
//	}
	
	public void setwaittime(int waittime)
	{
		this.waittime = waittime;
	}
	//getters
	public double getLat()
	{
		return latitude;
	}
	
	public double getLon()
	{
		return longitude;
	}
	
	public int getOrdernum()
	{
		return ordernum;
	}
	
	public int waittime()
	{
		return waittime;
	}
	//ignore this, this was made in an attempt
	@Override
	public int compareTo(Coordinate arg0) { 
		// TODO Auto-generated method stub
		return arg0.waittime() - this.waittime();
	}
	
}